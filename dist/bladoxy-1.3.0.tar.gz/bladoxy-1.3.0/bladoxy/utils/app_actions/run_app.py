from bladoxy.utils.print_info import echo_version_info
def run():
    echo_version_info()
    print("运行SSPrivoxy...")
    # Add your run logic here