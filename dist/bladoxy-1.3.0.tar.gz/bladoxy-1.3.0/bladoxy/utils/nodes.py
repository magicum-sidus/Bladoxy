def modify_node():
    print("修改节点...")
    # Add your modify logic here