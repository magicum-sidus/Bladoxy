def uninstall():
    print("正在卸载...")
    # Add your uninstallation logic here