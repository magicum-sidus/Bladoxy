def stop():
    print("正在停止进程...")
    # Add your stop logic here